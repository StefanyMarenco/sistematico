package arreglos;

import java.util.Scanner;

public class productoArreglos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado=new Scanner(System.in);
int vectorP[], vectorQ[];
int productoArreglo=0, productoModulo=0, Z;
int n, a, b;
System.out.println("Ingrese el tamaño de su arreglo");
n=teclado.nextInt();
vectorP=new int[n];
vectorQ=new int[n];
for(int j=0; j<n; j++) {
	System.out.println("Ingrese los valores del vectorP");
	a=teclado.nextInt();
	vectorP[j]=a;
	System.out.println("Ingrese los valores del vectorQ");
	b=teclado.nextInt();
	vectorQ[j]=b;
	productoArreglo=(vectorP[j] * vectorQ[j]);
	productoModulo=vectorP[j] % vectorQ[j];
}
Z=productoArreglo/productoModulo;
System.out.println("El valor de la expresion Z es:"+Z);

	}

}
