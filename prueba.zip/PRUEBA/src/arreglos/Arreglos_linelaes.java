package arreglos;

import java.util.Scanner;

public class Arreglos_linelaes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado=new Scanner(System.in);
int vectorA[], vectorB[];
int n, productoPunto=0, x=0, y=0;
System.out.println("Ingrese el tamaño de su arreglo");
n=teclado.nextInt();
vectorA=new int[n];
vectorB=new int[n];
for(int i=0; i<vectorA.length; i++) {
	System.out.println("Ingrese los valores del vectorA");
	x=teclado.nextInt();
	vectorA[i]=x;
	System.out.println("Ingrese los valores del vectorB");
	y=teclado.nextInt();
	vectorB[i]=y;
	productoPunto=productoPunto+(vectorA[i] * vectorB[i]);
}

System.out.println("El producto punto  del arreglo es:"+productoPunto);
	}

}
